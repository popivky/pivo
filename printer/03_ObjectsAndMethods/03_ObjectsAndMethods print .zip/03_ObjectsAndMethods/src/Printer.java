public class Printer {
    private String queue = "";
    private int pagesCount = 0;
    private int documentsCount = 0;

    public Printer(String queue) {
        this.queue = this.queue + queue;
    }

    public void append(String text, String name, int pages) {

    }


    public void clear() {
        queue = "";
    }

    public void print(String text, String name, int pages) {
        if (contains(text)) {
            documentsCount = documentsCount++;
        }
        queue = queue + "\n" + text + " - " + name + " - " + pages + " стр";
        pagesCount = pagesCount + pages;
        System.out.println(queue);
        clear();
    }

    public int getPagesCount() {
        return pagesCount;
    }

    public int getDocumentsCount() {
        return documentsCount;
    }

    public boolean contains(String text) {
        return queue.contains(text);
    }
    public int totalPrint (String text)
}

